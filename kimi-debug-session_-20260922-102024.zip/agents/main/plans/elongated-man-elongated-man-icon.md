# 桌游设计师玩法重设计（v4：众筹系统）实施计划

背景：v1（投属性经验）/v3（出版定档）均已过时。本计划为当前定稿：**先只做众筹系统，出版玩法后续再规划**。挑战场景（Phase 1）已提交；设计师 v1 实现在工作区未提交，作为骨架保留改造。SAVE_VERSION 维持 15（v15 未发布；normalize 兼容旧字段）。

## 核心循环（v4 定稿）

**立项**（花 10 灵感）：名称（2~10 字）+ 类型（8 主题）+ 体量（小盒/标准/大盒）。体量决定牌套需求与成本价基数。

**开发迭代**：6 设计维度与六维属性一一对应（机制深度=谋略 / 数值平衡=演算 / 重开变化=应变 / 组件美工=洞察 / 规则条理=运筹 / 主题沉浸=沉浸），每维上限 5 次、第 n 次花 5n 灵感、单次增益 2+floor(0.4×属性等级)+主题主场维度+1；**属性永不消耗**。Q = clamp(1,100, round((30+Σ迭代×增益)×(1+0.08×scoreUp)))；稀有度：Q<50 N / <70 R / <90 SR / ≥90 SSR（只影响需求概率，不影响定价）。

**成本与定价**：
- 成本价 = round(体量基数 × (0.8+Q/100))；体量基数 小盒 120 / 标准 300 / 大盒 600
- 发布众筹时玩家定价：成本价的 **100%~1000%**（滑杆）
- 牌套需求（收藏区给该桌游套牌套的花费）：小盒 50 / 标准 150 / 大盒 300（`sleeveCost` 字段存于设计，现应用于存量 designed 副本的 applySleeve，未来出版玩法继续使用）

**众筹**（设计师众筹成功作品 <10 款时唯一发行方式；`designer.successCount` 计数）：
- 参数：目标人数 50~1000 任意整数；期限 30~120 天（**1 天 = 现实 24 秒**）；发起时锁定 Q/稀有度/成本价，原型转为众筹项目（不可再迭代）
- **逐秒需求模拟**（在线每 tick、离线按相同函数累计模拟，离线时长 cap 沿用 1h）：
  1. 基础关注人数 k = 随机 1~5 + floor(已支持人数/100)，clamp 上限 10
  2. 每人独立判定：随机两个钟意题材，每个与本作类型匹配 +10%
  3. 实际售价 < ¥200：+10%
  4. 溢价（售价/成本价，1~10）：+30% × (10−溢价)/9（100%→+30%，1000%→+0%，线性）
  5. 稀有度：N/R/SR/SSR 分别 +0/5/10/20%
  6. 挑战商店「畅销作家」：每级 +6%（royaltyUp 乘区改用于此）
  7. rand < p 则已支持人数 +1
- 到期判定：已支持人数 ≥ 目标 → **成功**：收入 = 支持人数 × 售价 入 money，successCount+1，进「已众筹成功」列表；未达标 → **失败**：原型退回（可重新发起），无收入
- 提前满额不结束：继续累积支持人数至到期（收入更高）

## 实施步骤

### 1. 数据层 `src/core/data/designs.ts`（v3 基础上改）

- 保留：DesignTheme（8）、DESIGN_DIMS（六维表）、FOUND_COST=10、INSPIRE_CAP=999、ITER_MAX=5、iterCost/iterGain、Q 公式与稀有度阈值
- SCALE 改为：`{ id, name, costBase, sleeveCost }` = 小盒{120,50} / 标准{300,150} / 大盒{600,300}
- 新增：`CROWD_GOAL_MIN=50, CROWD_GOAL_MAX=1000, CROWD_DAYS_MIN=30, CROWD_DAYS_MAX=120, DAY_SECONDS=24`、`rarityDemandBonus = {N:0,R:0.05,SR:0.10,SSR:0.20}`
- 移除：印刷/版税/定价常量（PRINT_*、PRICE_*、ROYALTY_*）与 priceOf/printCostOf；`costPriceOf(q, scale)`、`demandProb(campaign)` 公式入 mechanics

### 2. 状态层 `src/core/state.ts`

```ts
designer: {
  unlocked: boolean;
  inspiration: number;                 // cap 999
  prototypes: { uid, name, themeId, scale, iter: Record<string, number> }[];
  campaigns: { uid, name, themeId, scale, score (Q), rarity, costPrice, price,
               goal, days, elapsedSec, supporters }[];   // 进行中
  funded: { uid, name, score, rarity, price, supporters, income }[];  // 已成功
  failed: { uid, name, goal, days, supporters }[];      // 已失败（原型退回）
  nextUid: number;
  successCount: number;
};
```
normalize 兼容 v1/v3 旧字段（invested/insp/无 iter→全 0；published 旧数组→并入 funded 或剔除，选一并注释；campaigns/funded/failed 缺省补空）。

### 3. 引擎 `src/core/engine/design.ts`

- `foundPrototype` / `iterateProto`：v3 语义
- `launchCrowd(state, protoUid, goal, days, ratio)`：校验 proto 存在、successCount<10（≥10 时提示后续版本开放直接出版）、goal/days/ratio 范围 → 锁 Q/稀有度/成本价、price=round(costPrice×ratio)、proto 移入 campaigns
- `tickCrowd(state)`：挂 tickSecond；对每个 campaign 逐秒模拟（离线 accumulateOffline 复用同一逐秒函数，最多 OFFLINE_CAP 秒）；到期结算成功/失败（toast 事件返回）；收入入账、successCount、funded/failed 归类、原型退回
- 移除 tickRoyalties/accumulateRoyalties；OfflineBank 移除 royalties 字段；TickResult 清理

### 4. 其他消费点调整

- 挑战商店「royalty-up」：desc 改"每级：众筹购买概率 +6%"（id/key 不变，兼容已购存档），mechanics 乘区接入 demandProb
- 成就：data/achievements.ts 三个改为——灵光一现（首次立项）/ 一呼百应（首次众筹成功）/ 万众瞩目（单次众筹支持人数 ≥800）
- 存量 designed 副本的 applySleeve 用 sleeveCost（v1 已排除游玩/转生权重，保留）；collections 排除逻辑保留
- save normalize / OfflineModal 版税行移除

### 5. UI `src/ui/pages/DesignPage.vue`

- 立项区（名称+主题+体量，显示体量对应的成本基数与牌套需求）
- 原型卡：6 维度迭代（v3 设计）+「发起众筹」区——目标人数输入（50~1000）、期限滑杆（30~120 天，显示现实分钟数）、定价滑杆（100%~1000%，显示成本价与最终售价）、成功率预估提示、确认按钮
- 进行中众筹列表：进度条（支持人数/目标）、剩余天数、售价、稀有度徽标、预估收入
- 已众筹成功列表（successCount 总数置顶，<10 时提示"还差 N 款解锁出版"）/ 已失败列表
- store actions：foundPrototype/iterateProto/launchCrowd 薄封装

### 6. 测试 `tests/designer.test.ts`

保留 v1 仍有效的（解锁、灵感入账、迁移）；改写：foundPrototype/iterateProto 契约、Q/稀有度、成本价公式（例：Q=60 标准 → round(300×1.4)=420）、demandProb 链逐项断言（题材匹配+10%、价格<200 +10%、溢价 100%→+30%/1000%→+0%/中间线性、稀有度 0/5/10/20%、人气+6%/级）、逐秒模拟确定性（lcg 注入：构造 p=1 必买、p=0 不买两例）、到期成功/失败结算（收入=人数×售价、successCount、原型退回）、goal/days/ratio 越界拒绝、≥10 款后 launchCrowd 拒绝。全量 `npm run typecheck && npm run test && npm run build` 绿。

### 7. 文档

docs/challenges-designer.md 设计师节替换为 v4 定稿（众筹规则全文、公式、参数表）；CHANGELOG v0.2 条目措辞改为众筹系统。

### 8. 验收

浏览器冒烟：解锁 → 立项（取名/类型/体量）→ 迭代 → 发起众筹（参数边界各试一次）→ 观察逐秒支持人数增长 → 到期结算正确。
