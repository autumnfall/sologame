# 挑战场景 + 桌游设计师玩法 设计方案与实施计划

## 总体结构

两条新系统，共享一套"元进度"框架：

- **挑战场景**（先做）：挑战按**三层前置树**解锁（仿天赋树 `after` 链式结构）；周目内激活一个挑战（带条件修饰 + 目标），完成获得**挑战币**；**每挑战只发一次币**，已完成记录跨周目保留（存 `prestige`）；币用于兑换**全局加成**——既有收藏向的，也有设计师向的（这是和现有一切加成只在收藏线生效的关键区别）。
- **桌游设计师**（后做）：担任「桌游设计师」职业后解锁（周目内永久）。消耗**灵感**（从游玩收藏中获得）+ **六维属性经验**（会真实扣等级，与保职业需求形成张力）→ 设计原型 → 花钱出版 → 产出自己的桌游实体（可挂某鱼出售）+ 持续版税。

关键设计决策：

1. 挑战币、挑战商店等级、已完成挑战列表都存在 `prestige` 里（跨周目保留），并在 `engine/prestige.ts:32` 的白名单加入新字段。
2. 挑战「条件修饰」全部实现为现有乘区/开关的读取点扩展，仿照 `perkLv` 的 key-based 模式，新建 `mechanics/challenge.ts` 与 `mechanics/prestige.ts:22` 并列。
3. 设计师产出的桌游**不进入 `GAMES` 表**（独立 id 空间 `data/designs.ts`），避免污染图鉴/转生权重/成就遍历；实体复用现有 `Copy` 结构加 `designed?: true` 标记。
4. 离线结算（`accumulateOffline`）同样遵守挑战修饰（禁用工资等），与在线共用修饰函数。

## 配平账目（币供给 vs 商店成本）

- 币供给：8 个挑战一次性奖励合计 **22 币**。
- 商店总成本：全部升满 **20 币**。
- 结论：全收集恰好可达（余 2 币余量），但受前置链约束必须按顺序投资，不能开局全买。后续版本新增挑战 = 纯余量，新增商店内容则要同步加挑战。

## Phase 0：设计文档

写 `docs/challenges-designer.md`：完整数值表（挑战树、币奖励、商店价格表、灵感公式、评分公式、印刷费、版税率）、存档变更登记。后续两个 Phase 的代码以它为准。

## Phase 1：挑战场景（SAVE_VERSION 12 → 13）

### 1. 数据层 `src/core/data/challenges.ts`（新建）

```ts
interface ChallengeDef {
  id: string;
  name: string;
  desc: string;
  /** 前置：需已完成这些挑战（空/缺省 = 第一层，开局即可见） */
  requires?: string[];
  mods: {
    noJobIncome?: boolean;    // 禁用工作收入（在线+离线）
    xyRefreshMult?: number;   // 某鱼刷新间隔倍率（<1 更快）
    xyCountMult?: number;     // 到货件数倍率
    expMult?: number;         // 六维经验倍率
    fatigueIncMult?: number;  // 疲劳增长倍率
    gachaPriceMult?: number;  // 某赏价格倍率（>1 更贵）
    noPlay?: boolean;             // 禁止游玩（在线主动开局 + 离线自动游玩全禁）
    maxDistinctCopies?: number;   // 收藏架最多可同时持有多少款不同桌游的实体；到上限后所有购入渠道（某宝/某鱼含盲买/某赏）拒绝获得"新款"桌游（已有款的加购副本不受影响）
    startMoneyBonus?: number;     // 激活挑战时立得资金（花佬：游玩被禁，补偿起步资金）
    sellChanceMult?: number;      // 某鱼成交率倍率（叉叉：腾位循环依赖快出货）
  };
  goal: { type: GoalType; target: number };
  reward: number;             // 挑战币（一次性）
}
type GoalType = 'xyEarn' | 'bargainBuys' | 'masteryCount' | 'plays' | 'highPriceSold' | 'pulls' | 'distinctCopies' | 'distinctCollections';
```

GoalType 说明：`distinctCopies` = 收藏架上存在实体的不同桌游款数（copies 去重 gameId）；`distinctCollections` = 已开图鉴的收藏款数（collections 条目数，卖光也算——`CollectionEntry` 是账号级进度，`state.ts:4`）。

**挑战树（8 个，三层）**：

| 层 | id | 名称 | 条件 | 目标 | 币 | 前置 |
|---|---|---|---|---|---|---|
| 1 | no-salary | 无薪挑战 | 无工作收入 | 某鱼卖出净额 ¥2000 | 2 | — |
| 1 | marathon | 肝帝 | 疲劳增长 ×1.5 | 游玩 100 局 | 2 | — |
| 2 | flea-market | 捡漏之王 | 刷新间隔 ×0.5、件数 ×2 | 捡漏 5 次 | 2 | no-salary |
| 2 | merchant | 壮壮 | 某鱼件数 ×0.5 | 200% 定价高价成交 10 次（highPriceSold） | 3 | no-salary |
| 2 | hardcore | 硬核玩家 | 经验 ×0.6 | 精通 3 款 | 3 | marathon |
| 3 | big-earner | 叉叉 | 架上最多 5 款不同桌游实体；某鱼成交率 ×1.2 | 图鉴收藏 20 款（distinctCollections） | 4 | flea-market, merchant |
| 3 | collector | 花佬 | 不可游玩桌游；激活时资金 +¥1000 | 架上 30 款不同桌游实体（distinctCopies） | 4 | hardcore |
| 3 | whale | 柠檬佬 | 某赏价格 ×1.5 | 抽赏 100 次 | 2 | hardcore |

叉叉的玩法循环：买新款 → 开图鉴 → 卖掉腾位 → 再买下一款（图鉴卖光保留，见 `state.ts:4` 注释）。合计供给 22 币。`requires` 全部满足才显示/可激活。

**挑战币商店 `CHALLENGE_SHOP`**（仿 `data/prestige.ts` PerkDef 的 `{id, key, name, desc, max, base, step, after}`；`cost = base + step × 当前等级`，全部 base=1、step=0 即每级 1 币）：

| 线 | id | 名称 | 效果 | max | 小计 | 前置 |
|---|---|---|---|---|---|---|
| 收藏 | exp-boost | 博览群玩 | 全局经验 +5%/级 | 5 | 5 | — |
| 收藏 | xy-eye | 火眼金睛 | 某鱼好货（高成色/带牌套）概率 +8%/级 | 3 | 3 | exp-boost ≥1 |
| 设计 | insp-up | 灵感如泉 | 灵感获取 +15%/级 | 5 | 5 | — |
| 设计 | score-up | 匠心独运 | 设计评分 +8%/级 | 4 | 4 | insp-up ≥1 |
| 设计 | royalty-up | 畅销作家 | 版税率 +12%/级 | 3 | 3 | score-up ≥1 |

合计 20 币。设计师向加成在 Phase 2 才生效，Phase 1 先定义不消费。

### 2. 状态层 `src/core/state.ts`

```ts
// GameState 新增（周目级）：
challenge: { active: string | null; progress: number };
// PrestigeState 新增（跨周目保留）：
coins: number;                       // 挑战币
shop: Record<string, number>;        // 挑战商店等级
challengeDone: string[];             // 已完成挑战（一次性奖励的依据）
```

`defaultState()`、`defaultPrestige()` 同步初始值。`engine/prestige.ts:32` 保留白名单加入 `coins`、`shop`、`challengeDone`。

### 3. 机制层 `src/core/mechanics/challenge.ts`（新建）

- `challengeMods(state)`：返回当前激活挑战的 mods（无激活则全默认）。
- `challengeShopLv(state, key)`：与 `perkLv` 并列的读取器。
- `challengeAvailable(state, id)`：检查 `requires` 是否全部在 `prestige.challengeDone` 中。
- `goalProgress(state)`：按 goal.type 从 `state.stats` / 收藏推导当前进度（`xyEarn` 需要新统计：在成交通道累计销售额进 `stats.xyEarned`）。
- `checkChallenge(state)`：每秒 tick 扫描（仿 `mechanics/achievements.ts:26`），进度更新；达成且未领过奖励则 `prestige.challengeDone.push(id)`、`prestige.coins += reward`、`active = null`，返回事件供 toast。已完成的挑战不可再激活。

### 4. 引擎挂钩（消费修饰）

- `engine/tick.ts:28 tickSecond`：`noJobIncome` 时跳过工作发薪（仍推进 jobProgress）。
- `engine/tick.ts:58 accumulateOffline`：离线工作结算同样跳过（离线也要遵守挑战规则）。
- `engine/xianyu.ts:132`：回写 `xyNext` 时用 `XY_REFRESH_MS × xyRefreshMult`。
- `engine/xianyu.ts:46 refreshXianyu`：件数 `n = round((marketSlots + 1) × xyCountMult)`，clamp 1~15；`xy-eye` 加成在此处提高高成色/牌套概率（透传 challengeShopLv）。
- `mechanics/economy.ts:18 expMult`：乘入 `challengeMods.expMult` 与商店 `exp-boost`。
- `mechanics/play.ts` 疲劳增长处：乘入 `fatigueIncMult`。
- `engine/gacha.ts`：价格乘区挂 `gachaPriceMult`（柠檬佬的 1.5×，在调用处乘入）；`maxDistinctCopies` 到限时拒抽（抽出的是新款桌游则拒绝并提示）。
- `noPlay`（花佬）：`beginRound` 入口（store `game.ts`）与离线自动游玩（`accumulateOffline` 内粘性目标连刷处）都拦截，提示"挑战限制：不可游玩"。
- `maxDistinctCopies`（叉叉）：所有获得桌游的渠道统一走 `engine/acquire.ts` → 在此处拦截"新款"（当前架上没有的 gameId）购入：某宝购买、某鱼购买（含盲买）、某赏抽赏、开局赠送/天赋赠送。出售不受限制（腾位就靠卖）。
- `engine/tick.ts` 主链挂 `checkChallenge`（放在 `checkAchievements` 旁边）。
- 成交通道（`engine/xianyu.ts` 售出结算）累计 `stats.xyEarned`。
- `startMoneyBonus`（花佬）：`startChallenge` 激活成功时一次性 `money += 1000`（放弃挑战不退回，防止刷钱）。
- `sellChanceMult`（叉叉）：某鱼成交率计算处（`balance.ts:129` 的 `sellChance`，与好口碑天赋乘区并列）乘入 1.2。

### 5. UI 层

- `src/ui/stores/game.ts`：`TabKey` 增加 `'challenge'`；store actions：`startChallenge(id)`（校验 available + 未完成）、`abandonChallenge()`、`buyChallengeShop(id)`（薄封装 → core 函数 → toast + saveGame，照现有模式）。
- 新建 `src/ui/pages/ChallengePage.vue`：挑战卡片按层展示（未解锁的显示"需完成 XXX"）；卡片含条件/目标/奖励/状态、激活/放弃按钮、进度条；下方挑战商店两线展示（币余额、升级按钮、`after` 前置灰显）。
- `App.vue` 注册新 tab；挑战入口开局即可见。
- 目标进度实时显示：页面直接读 `store.s.challenge.progress` / `goalProgress`。

### 6. 存档与迁移

- `constants.ts`：`SAVE_VERSION = 13`，注释登记。
- `engine/save.ts`：v12→v13 migration（可为恒等，参照 v9→v12 做法）；`normalize` 补 `challenge`、`prestige.coins`、`prestige.shop`、`prestige.challengeDone` 默认值并校验（未知挑战/商店 id 剔除）。

### 7. 测试 `tests/challenge.test.ts`

仿现有测试用 `tests/helpers.ts` 的 `lcg(seed)`：

- 激活 no-salary 后在线 tick 与离线结算均不发薪。
- flea-market 的 xyNext 间隔与到货件数正确翻倍。
- hardcore 的 expMult 生效（settleRound 经验断言）。
- 目标达成 → 币入账、challengeDone 记录、active 清空；**再次激活已完成挑战被拒**（一次性）。
- 前置：big-earner 在 flea-market/merchant 未完成时 `challengeAvailable = false`。
- 花佬：激活后 `beginRound` 被拒、离线自动游玩跳过；架上 30 款不同实体时 `distinctCopies` 目标达成。
- 叉叉：架上 5 款时某宝/某鱼/某赏购入"新款"被拒，购入已有款副本放行；卖掉一款后图鉴保留（distinctCollections 计数不回落），可再买新款。
- 挑战商店购买 → 对应乘区生效；`after` 前置未满足时购买被拒。
- 存档迁移：v12 旧档 normalize 后新字段有默认值。

## Phase 2：桌游设计师（SAVE_VERSION 15；v2 重设计：灵感=开发燃料，属性=能力加成不消耗）

### 核心循环（v2 定稿）

**立项**：玩家输入名称（2~10 字）+ 选主题，消耗 10 灵感 → 生成原型。
**开发迭代**：原型有 4 维度，各自独立迭代（上限 5 次/维度），**花灵感不扣属性**：

| 维度 | 关联属性 | 单次迭代质量增益 |
|---|---|---|
| 机制设计 | 主题主属性 | 2 + 0.4 × 该属性等级 |
| 数值平衡 | 演算 | 同上 |
| 美术包装 | 洞察 | 同上 |
| 规则打磨 | 沉浸 | 同上 |

单维度第 n 次迭代花 5n 灵感（5/10/15/20/25，点满一维 75）。属性等级只提供加成（设计师懂行→迭代收益高），永不消耗、永不降级。
**出版定档规则**（质量分 Q，先乘 score-up 再 clamp 100）：

| Q | 稀有度 | 定价 | 附赠牌套资源 | 属性偏好（该桌游的 attrs） |
|---|---|---|---|---|
| <50 | N | round(60×(0.8+Q/100)) | 5 | [主属性, 副属性] |
| <70 | R | round(150×(0.8+Q/100)) | 10 | 同上 |
| <90 | SR | round(400×(0.8+Q/100)) | 20 | 同上 |
| ≥90 | SSR | round(1200×(0.8+Q/100)) | 40 | 同上 |

印刷费 = 300 + Q²×2；产出 10 份实体（全部 sleeved=true，耐久 80 SSR 档）+ 上表牌套资源；版税沿用：每 tick 概率 Q/20000，命中 round(price×0.1×royalty-up×1/(1+天数))。

### 1. 数据层 `src/core/data/designs.ts`（v1 已建，v2 改造）

- `DesignTheme` 已有 mainAttr/subAttr（保留）；维度→属性映射常量：`DIM_ATTR: { mech: 'main', balance: '演算', art: '洞察', rules: '沉浸' }`（mech 解析为主题主属性）。
- 新增常量：`FOUND_COST=10`、`ITER_MAX=5`、`iterCost(n)=5n`、`iterGain(level)=2+0.4×level`（取整策略定稿写入注释）、`RARITY_TIER: {N:{price:60,sleeves:5}, R:{150,10}, SR:{400,20}, SSR:{1200,40}}`、`PRINT_BASE=300`、`PRINT_SQ_COEF=2`。
- 移除：MAX_INVEST_PER_ATTR、SCORE_BASE 改 Q_BASE=30。
- `qualityOf(proto, state)`：Q_BASE + Σ维度(iter × iterGain(对应属性等级))，出版时 ×(1+0.08×scoreUp) 后 clamp(1,100)。
- `rarityOf(q)`、`priceOf(q)`、`sleeveBonusOf(q)`。

### 2. 状态层

```ts
designer: {
  unlocked: boolean;
  inspiration: number;              // 灵感（cap 999）
  prototypes: { uid: number; name: string; themeId: string;
                iter: { mech: number; balance: number; art: number; rules: number } }[];
  published: (PublishedDesign & { rarity: Rarity })[];  // v1 无 rarity 字段，出版时定档写入
};
```
`PublishedDesign` 增 `rarity`；`attrs` 由 theme 主+副导出（属性偏好）。normalize：旧 v1 形态 prototype（invested/insp 字段）→ iter 全 0 迁移或剔除，选实现并写入注释；published 缺 rarity → 按 score 重算 rarityOf。

### 3. 引擎 `src/core/engine/design.ts`（v2 改造）

- `gainInspiration`：不变（settleRound 挂钩，N+1/R+2/SR+4/SSR+8 隐藏×2 × insp-up），cap 999。
- `foundPrototype(state, name, themeId)`：校验 unlocked、名称长度 2~10、灵感 ≥10 → 扣 10 → prototype（iter 全 0）。替代 v1 `designPrototype`（删除属性投入逻辑）。
- `iterateProto(state, protoUid, dim)`：校验维度未满、灵感 ≥ iterCost(n+1) → 扣灵感、iter[dim]+1。
- `publishDesign(state, protoUid)`：Q=qualityOf × score-up → rarity/price/sleeves → 扣印刷费 → 10 份 sleeved 实体 + sleeves 资源入 state.sleeves → collections 建条目（不计入 prestigeWeight/图鉴，排除逻辑 v1 已就位不动）。
- `tickRoyalties`/`accumulateRoyalties`：概率与金额改用 Q（published.score 即 Q），其余不变。
- 某鱼出售通道 v1 已通（copyValueOf/copyRarity），不动。

### 4. 解锁与成就

v1 已就位：takeJob master → unlocked；3 成就；挑战商店三加成（score-up 现作用于 Q，insp-up 作用于灵感获取，royalty-up 版税——均已有消费点，仅公式换源）。

### 5. UI 层（DesignPage v2 改造）

- 立项区：名称输入框（2~10 字校验提示）+ 主题选择 + 「立项」按钮（显示 -10 灵感）。
- 原型卡：名称/主题/当前 Q 与稀有度预估；4 维度各一行——已迭代次数/5、下次花费灵感、该维度关联属性与当前等级、迭代按钮（灵感不足灰显）。
- 出版按钮：显示印刷费、Q、稀有度、定价、附赠牌套预览。
- 已出版列表：名称/稀有度徽标/Q/单价/累计版税。
- store actions：foundPrototype/iterateProto/publishDesign 薄封装。

### 6. 存档

SAVE_VERSION 维持 15（v15 未发布过，直接改形态）；normalize 兼容 v1 旧字段（prototype invested/insp、published 无 rarity）如上。

### 7. 测试 `tests/designer.test.ts`（v2 改写 + 保留 v1 仍有效的）

- 保留：unlocked 解锁、灵感入账 × insp-up、出版产出 10 实体/不计入权重/图鉴、版税命中与衰减、迁移。
- 改写/新增：foundPrototype 扣 10 灵感、名称校验；iterateProto 扣递增灵感、增益=2+0.4×等级（钉死一个数值例：等级 5 → +4）、维度上限 5；**属性经验全程不动**（断言 attrExp 不变）；出版定档表 4 档（lcg/手工构造各档 Q 断言 rarity/price/sleeves：Q=40→N/round(60×1.2)=72/5 张；Q=60→R/round(150×1.4)=210/10；Q=80→SR/round(400×1.6)=640/20；Q=95→SSR/round(1200×1.75)=2100/40）；score-up 影响 Q；产出实体 sleeved=true。

## 实施顺序与验证

每个 Phase 内按：设计文档 → data → state → mechanics → engine → UI → 迁移 → 测试。每 Phase 结束跑 `npm run typecheck`、`npm run test`、`npm run build` 全绿才算完成；最后用 dev server 手动走一遍核心流程（激活挑战→完成→币入账→买加成；担任设计师→设计→出版→挂某鱼卖出）。

## 明确不做（本期）

- 桌游吧玩法（第三阶段，等设计师数值跑过真实试玩再定）。
- 在线排行榜挑战成绩上报。
- 挑战的计时类目标（需要独立计时器，先靠 stats 计数器覆盖）。
